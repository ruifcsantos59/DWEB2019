var http = require ('http');
var fs = require ('fs');

const server = http.createServer((req, res) => {
  const partes = req.url.split('/');
  var pag = partes[partes.length - 1];

  console.log(pag);

  if(pag.match(/favicon.ico/)){
    res.end();
  } else {
    fs.readFile('arq' + pag + '.xml', (err, data) => {
      res.writeHead(200, {'Content-Type' : 'text/xml'});
      res.write(data);
      res.end();
    });
  }

});

server.listen(7777);